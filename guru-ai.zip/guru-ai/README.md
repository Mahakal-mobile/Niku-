# Guru AI

A production-ready, single-page **React + Vite** personal AI companion with a dark/gold mobile-first UI.

Guru is designed to feel like a close friend — witty, empathetic, and capable — while staying professional for work tasks. It knows the **Nothing Phone (3a) Lite / Nothing OS** inside-out and is built for live search, camera diagnosis, voice, long-term memory, and future deep integrations (WhatsApp, Gmail, X, etc.).

## Features

- **Sleek dark UI** with gold accents, mobile-first
- **Chat** powered by Google Gemini (`gemini-2.0-flash`)
- **Voice input** via Web Speech API
- **Camera & gallery** — capture or upload images/PDFs for analysis (mobile repair diagnosis, etc.)
- **Shortcut actions**: Mobile Repair · Explain · Web Search · Writing · Camera/Media
- **Live web knowledge** through Gemini (weather, prices, news, flights…)
- **Long-term memory** (local, up to 1 year) — say “remember …”
- **API-key ready architecture** for WhatsApp, Gmail, X, Facebook
- **Device expertise** for Nothing Phone (3a) Lite / Nothing OS
- **SPA routing** configured for Vercel & Netlify (no 404s on refresh)

## Quick start (local)

```bash
cd guru-ai
cp .env.example .env
# Edit .env and set VITE_GEMINI_API_KEY=your_key
npm install
npm run dev
```

Get a free Gemini key: https://aistudio.google.com/apikey

## Deploy on Vercel

1. Push this folder to a GitHub repo.
2. Import the project in Vercel.
3. Add environment variable:
   - `VITE_GEMINI_API_KEY` = your Gemini API key
4. Deploy. `vercel.json` already handles SPA rewrites.

Or CLI:

```bash
npm i -g vercel
vercel
# set the env var in the dashboard or with vercel env add
```

## Deploy on Netlify

1. Connect the repo in Netlify.
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Add env var `VITE_GEMINI_API_KEY`.
5. `netlify.toml` already configures redirects and headers.

## Project structure

```
guru-ai/
├── public/
├── src/
│   ├── components/     # Header, Shortcuts, MessageList, ChatInput, Settings, Camera
│   ├── hooks/          # useChat, useSpeech, useCamera
│   ├── lib/            # gemini, storage, constants
│   ├── types/
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── vite.config.ts
├── vercel.json
├── netlify.toml
├── .env.example
└── package.json
```

## Notes on integrations

- **WhatsApp / Gmail / X**: Settings UI accepts keys. Actual OAuth/token exchange and server-side messaging require a small backend (recommended for production secrets). The architecture is ready — wire your proxy endpoints when you have them.
- **Screen / notification monitoring**: Browser security prevents silent reading of other apps. On-device companion apps or browser extensions would be needed for true notification access; Guru is prepared to consume summarized payloads if you supply them.
- **Memory**: Stored in `localStorage` with a 1-year expiry layout. Clear site data to reset.

## License

MIT — use it, fork it, ship it.
