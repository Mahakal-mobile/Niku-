import { useState, useEffect } from 'react'
import { X, Key, Smartphone, Brain } from 'lucide-react'
import type { AppSettings } from '../types'
import { loadSettings, saveSettings } from '../lib/storage'
import { initGemini } from '../lib/gemini'
import { DEVICE_MODEL, DEVICE_OS } from '../lib/constants'

interface SettingsModalProps {
  open: boolean
  onClose: () => void
  onApiChange: (ready: boolean) => void
}

export function SettingsModal({ open, onClose, onApiChange }: SettingsModalProps) {
  const [settings, setSettings] = useState<AppSettings>(loadSettings)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (open) setSettings(loadSettings())
  }, [open])

  if (!open) return null

  const updateKey = (field: keyof AppSettings['apiKeys'], value: string) => {
    setSettings((s) => ({
      ...s,
      apiKeys: { ...s.apiKeys, [field]: value },
    }))
    setSaved(false)
  }

  const handleSave = () => {
    saveSettings(settings)
    const ok = initGemini(settings.apiKeys.gemini || '')
    onApiChange(ok)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.7)',
        zIndex: 50,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
      }}
      onClick={onClose}
    >
      <div
        className="animate-fade-in"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: 480,
          maxHeight: '85vh',
          overflowY: 'auto',
          background: 'var(--bg-secondary)',
          borderTopLeftRadius: 20,
          borderTopRightRadius: 20,
          border: '1px solid var(--border)',
          borderBottom: 'none',
          padding: '20px 20px 32px',
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: 20,
          }}
        >
          <h2 style={{ fontSize: 18, fontWeight: 600 }}>Settings</h2>
          <button onClick={onClose} style={{ padding: 6, color: 'var(--text-secondary)' }}>
            <X size={20} />
          </button>
        </div>

        {/* Device */}
        <section style={{ marginBottom: 24 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 10,
              color: 'var(--gold)',
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            <Smartphone size={16} /> Device
          </div>
          <div
            style={{
              background: 'var(--bg-tertiary)',
              borderRadius: 12,
              padding: 14,
              border: '1px solid var(--border)',
              fontSize: 13,
              color: 'var(--text-secondary)',
            }}
          >
            <div>
              <strong style={{ color: 'var(--text-primary)' }}>Model:</strong> {DEVICE_MODEL}
            </div>
            <div style={{ marginTop: 4 }}>
              <strong style={{ color: 'var(--text-primary)' }}>OS:</strong> {DEVICE_OS}
            </div>
            <p style={{ marginTop: 8, fontSize: 12, lineHeight: 1.4 }}>
              Guru has built-in knowledge of Glyph, Nothing X, permissions, and repair paths for
              this device.
            </p>
          </div>
        </section>

        {/* API Keys */}
        <section style={{ marginBottom: 24 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 10,
              color: 'var(--gold)',
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            <Key size={16} /> API Keys
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>
            Keys stay in your browser / environment. Never leave secrets in the frontend for
            production backends — this is a client-side companion.
          </p>

          <label style={{ display: 'block', marginBottom: 14 }}>
            <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
              Gemini API Key (required for chat & search)
            </span>
            <input
              type="password"
              value={settings.apiKeys.gemini}
              onChange={(e) => updateKey('gemini', e.target.value)}
              placeholder="AIza…"
              style={{
                display: 'block',
                width: '100%',
                marginTop: 6,
                padding: '10px 12px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 14,
              }}
            />
          </label>

          <label style={{ display: 'block', marginBottom: 14 }}>
            <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
              WhatsApp API (optional – future messaging)
            </span>
            <input
              type="password"
              value={settings.apiKeys.whatsapp || ''}
              onChange={(e) => updateKey('whatsapp', e.target.value)}
              placeholder="Token / key"
              style={{
                display: 'block',
                width: '100%',
                marginTop: 6,
                padding: '10px 12px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 14,
              }}
            />
          </label>

          <label style={{ display: 'block', marginBottom: 14 }}>
            <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
              Gmail / Google (optional)
            </span>
            <input
              type="password"
              value={settings.apiKeys.gmail || ''}
              onChange={(e) => updateKey('gmail', e.target.value)}
              placeholder="OAuth client / token"
              style={{
                display: 'block',
                width: '100%',
                marginTop: 6,
                padding: '10px 12px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 14,
              }}
            />
          </label>

          <label style={{ display: 'block', marginBottom: 14 }}>
            <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>X / Twitter (optional)</span>
            <input
              type="password"
              value={settings.apiKeys.x || ''}
              onChange={(e) => updateKey('x', e.target.value)}
              placeholder="Bearer token"
              style={{
                display: 'block',
                width: '100%',
                marginTop: 6,
                padding: '10px 12px',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border)',
                borderRadius: 10,
                fontSize: 14,
              }}
            />
          </label>
        </section>

        {/* Memory */}
        <section style={{ marginBottom: 24 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginBottom: 10,
              color: 'var(--gold)',
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            <Brain size={16} /> Memory
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.45 }}>
            Say “remember …” and I’ll store it for up to 1 year in local storage. Clear site data
            to wipe.
          </p>
        </section>

        <button
          onClick={handleSave}
          style={{
            width: '100%',
            padding: '12px',
            borderRadius: 12,
            background: 'linear-gradient(135deg, #f5c518, #d4a017)',
            color: '#0a0a0a',
            fontWeight: 600,
            fontSize: 15,
          }}
        >
          {saved ? 'Saved ✓' : 'Save settings'}
        </button>
      </div>
    </div>
  )
}
