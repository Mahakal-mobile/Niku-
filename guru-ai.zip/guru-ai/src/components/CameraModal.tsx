import { useEffect } from 'react'
import { X, Camera } from 'lucide-react'
import { useCamera } from '../hooks/useCamera'

interface CameraModalProps {
  open: boolean
  onClose: () => void
  onCapture: (dataUrl: string) => void
}

export function CameraModal({ open, onClose, onCapture }: CameraModalProps) {
  const { error, isActive, videoRef, start, stop, capture } = useCamera()

  useEffect(() => {
    if (open) {
      start()
    } else {
      stop()
    }
    return () => stop()
  }, [open]) // eslint-disable-line react-hooks/exhaustive-deps

  if (!open) return null

  const handleSnap = () => {
    const data = capture()
    if (data) {
      onCapture(data)
      onClose()
    }
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: '#000',
        zIndex: 60,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '12px 16px',
          background: 'rgba(0,0,0,0.6)',
        }}
      >
        <span style={{ fontWeight: 600 }}>Camera</span>
        <button onClick={onClose} style={{ padding: 6 }}>
          <X size={22} />
        </button>
      </div>

      <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {error ? (
          <p style={{ color: 'var(--danger)', padding: 24, textAlign: 'center' }}>
            {error}
            <br />
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Allow camera permission and try again.
            </span>
          </p>
        ) : (
          <video
            ref={videoRef}
            playsInline
            muted
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
            }}
          />
        )}
      </div>

      <div
        style={{
          padding: '20px',
          display: 'flex',
          justifyContent: 'center',
          background: 'rgba(0,0,0,0.7)',
        }}
      >
        <button
          onClick={handleSnap}
          disabled={!isActive}
          style={{
            width: 68,
            height: 68,
            borderRadius: '50%',
            border: '4px solid var(--gold)',
            background: 'var(--bg-elevated)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--gold)',
          }}
        >
          <Camera size={28} />
        </button>
      </div>
    </div>
  )
}
